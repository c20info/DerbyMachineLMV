import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Grafica extends JFrame {
    public static int w;
    public static int h;
    private Grafica g;
    private Background background;
    private int gett;   //gettoni

    public Grafica(int x, int y, int w, int h){
        this.w = w;
        this.h = h;
        this.setBounds(x,y,w,h);
        this.setTitle("Horse Competition");
        this.background = new Background();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        this.setVisible(true);
        this.add(background,0);
        gett = new Random().nextInt(5)+1;
        background.setVisible(false);
        g = this;
    }

    public void menu(){
        radioButton b = new radioButton(30,30);
        b.startButton(30,30);
        Gestore.gr.remove(b);
        Gestore.gr.setSize(1500,500);
    }

    public void remove(radioButton rb){
        this.remove(rb.pulsante);
        this.remove(rb.r1);
        this.remove(rb.r2);
        this.remove(rb.r3);
        this.remove(rb.r4);
        this.remove(rb.scritta);
        this.remove(rb.gettoni);
    }

    public class radioButton extends ButtonGroup{

        private gestioneButton pulsante = new gestioneButton(250,400,"Start Competition",Color.BLUE, background);
        private JRadioButton r1=new JRadioButton("First Horse");
        private JRadioButton r2=new JRadioButton("Second Horse");
        private JRadioButton r3=new JRadioButton("Third Horse");
        private JRadioButton r4=new JRadioButton("Fourth Horse");
        private JLabel scritta = new JLabel("These are your tokens");
        private JLabel gettoni = new JLabel(String.valueOf(gett));

        public radioButton(int cordx, int cordy){
        r1.setBounds(50,50,100,30);
        r2.setBounds(50,100,100,30);
        r3.setBounds(50,150,100,30);
        r4.setBounds(50,200,100,30);
        scritta.setBounds(250,250,150,30);
        gettoni.setBounds(250,300,150,30);
        g.add(r1,0);g.add(r2,0);g.add(r3,0);g.add(r4,0);g.add(scritta,0);g.add(gettoni,0);
        this.add(r1);this.add(r2);this.add(r3);this.add(r4);
        g.setSize(500,500);
        }

        public int startButton(int cordx, int cordy){
            int horseSelected = 0;
            while(!pulsante.isActive()){
                horseSelected = getSelected();
            }
            return horseSelected;
        }

        public int getSelected(){
            if(r1.isSelected())
                return 1;
            if(r2.isSelected())
                return 2;
            if(r3.isSelected())
                return 3;
            if(r4.isSelected())
                return 4;
            return 0;
        }
    }
}
