import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Cavallo extends JPanel {
    private int cordx;
    private int cordy;
    private int num;
    public static int vincitore = -1;
    private JLabel vittoria;
    private int velocita, accel, resistenza, probabilitaRottura;                    //probabilità della rottura della zampa
    private BufferedImage img;

    public Cavallo(int cordx, int cordy, String nome, int num) throws IOException{
        this.cordx = cordx;
        this.cordy = cordy;
        this.num = num;
        img = ImageIO.read(new File(nome));
        this.setBounds(cordx,cordy, 600,600);
    }

    public void move() {
        if (cordx < Grafica.w - 90) {
            cordx += new Random().nextInt(5) + 1;
            velocita = new Random().nextInt(5)+1;
            accel = new Random().nextInt(5)+1;
            resistenza = new Random().nextInt(5)+1;
            probabilitaRottura = new Random().nextInt(5)+1;
        }else if(vincitore < 0){
            vincitore = num;
        }
        this.setBounds(cordx, cordy, 60, 60);
    }

    //public void setCordx(int cordx){this.cordx = cordx;}
    //public int getCordx(){return cordx;}

    @Override
    public void paintComponent(Graphics g){
        g.drawImage(img.getScaledInstance(60,60,0),0,0,this);
    }
}
