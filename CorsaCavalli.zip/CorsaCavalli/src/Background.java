import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Background extends JPanel {
    private BufferedImage background;

    public Background(){
        try{
            background = ImageIO.read(new File("campo.jpg"));
        }catch(Exception e){}
        this.setBounds(0,0,1500,500);
        this.setVisible(true);
    }
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        //g.drawImage(background.getScaledInstance(1500, 500, 0), 0, 0, this);
        g.drawImage(background.getScaledInstance(Gestore.gr.getWidth(), Gestore.gr.getHeight(),0),0,0,this);
    }
}
