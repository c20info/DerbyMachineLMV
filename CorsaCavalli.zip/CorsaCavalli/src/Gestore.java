import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.*;

public class Gestore {
        public static Grafica gr = new Grafica(0,0,1500,500);

        public static void main(String[] args) throws InterruptedException, IOException{
                try {
                        Image image = new ImageIcon("logo.jpg").getImage();
                        gr.setIconImage(image);
                }catch(Exception e){System.out.println("Application icon not found");}
                Cavallo c = new Cavallo(0,30,"cavallo.jpg",1);
                Cavallo c2 = new Cavallo(0,150,"cavallo2.jpg",2);
                Cavallo c3 = new Cavallo(0,260,"cavallo3.jpg",3);
                Cavallo c4 = new Cavallo(0,380,"cavallo4.jpg",4);
                gr.menu();
                gr.add(c,0);gr.add(c2,0);gr.add(c3,0);gr.add(c4,0);
                while(Cavallo.vincitore < 0){
                        c.move();c2.move();c3.move();c4.move();
                        Thread.sleep(10);
                }
                Thread.sleep(1000);
                gr.getContentPane().removeAll();
                gr.repaint();
                gr.setSize(300,300);
                JLabel vittoria = new JLabel();
                vittoria.setBounds(gr.getWidth()/2 - 65, gr.getHeight()/2 - 7,200,20);
                gr.add(vittoria,0);
                vittoria.setText("Ha vinto il cavallo: " + Cavallo.vincitore);
        }
}
